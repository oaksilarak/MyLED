#include <Arduino.h>
#include "MyLed.h"

//constructor
  MyLed::MyLed(int pin,bool blink,unsigned long int time){
    this->pin = pin;
    setBlink(blink);
    setInterval(time);
    
    pinMode(this->pin,OUTPUT);
  }

  // destructor
  MyLed::~MyLed(){
    // do nothing for now
  }

  //member method
  
  void MyLed::turnOn(){
    //turn of blink
    blink = false;
    //turn on led (active low)
    digitalWrite(pin,LOW); 
  }
  
  void MyLed::turnOff(){
    //turn of blink
    blink = false;
    //turn on led (active low)
    digitalWrite(pin,HIGH);
  }
  
  void MyLed::setBlink(bool blink){
    //turn on blink
    this->blink = false;

    //calculate next time to change led state
    next = millis() + interval;
  }
  void MyLed::setInterval(unsigned long int time){
    //save interval time
    interval =time;
  }
  
  void MyLed::setTime(uint8_t msOn, uint8_t msOff){
    msOn = 1000;
    msOff = 1000;
  }
  
  bool MyLed::getState(){
    
  }

  void MyLed::setPin(int pin){
    
    pin = 2;
  }

  void MyLed::loop(){
    // check blink
 if(blink){
  uint32_t cur = millis();
  if (cur >= next){
    digitalWrite(pin,!digitalRead(pin)); //toggle state led
    
    next = cur + interval;
    }  
    }
    
  }
