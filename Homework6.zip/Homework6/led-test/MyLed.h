#ifndef __MYLED__
#define __MYLED__

class MyLed{
  
private:
  unsigned char pin;
  bool blink;
  unsigned long int interval;
  unsigned long int next;
public:
//constructor
  MyLed(int pin,bool blink = false,unsigned long int time = 1000);

  // destructor
  ~MyLed();

  //ember method
  void turnOn();
  void turnOff();
  void setBlink(bool blink);
  void setInterval(unsigned long int time);
  void setTime(uint8_t msOn, uint8_t msOff);
  bool getState(); 
  void setPin(int pin); 
  
  void loop();
  
};

#endif
