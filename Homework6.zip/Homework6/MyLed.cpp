#include <Arduino.h>
#include "MyLed.h"

//constructor
  MyLed::MyLed(unsigned char pin,bool blink,unsigned long int time){
    this->pin = pin;
    setBlink(blink);
    setInterval(time);
    
    pinMode(this->pin,OUTPUT);
  }

  // destructor
  MyLed::~MyLed(){
    // do nothing for now
  }

  //member method
  
  void MyLed::turnOn(){
    //turn of blink
    blink = false;
    //turn on led (active low)
    digitalWrite(pin,LOW); 
  }
  
  void MyLed::turnOff(){
    //turn of blink
    blink = false;
    //turn on led (active low)
    digitalWrite(pin,HIGH);
  }
  
  void MyLed::setBlink(bool blink){
    //tyrn on blink
    blink = true;

    //calculate next time to change led state
    next = millis() + interval;
  }
  void MyLed::setInterval(unsigned long int time){
    //save interval time
    interval =time;
    
  }

  void MyLed::loop(){
    // check blink
 if(blink){
  uint32_t cur = millis();
  if (cur >= next){
    if(digitalRead(pin) == LOW)
      turnOff();
    else
      turnOn(); 
    next = cur + interval;
    }  
    }
    
  }
