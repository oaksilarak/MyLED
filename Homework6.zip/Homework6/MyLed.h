#ifndef __MYLED__
#define __MYLED__

class MyLed{
  
private:
  unsigned char pin;
  bool blink;
  unsigned long int interval;
  unsigned long int next;
public:
//constructor
  MyLed(unsigned char pin,bool blink = false,unsigned long int time = 1000);

  // destructor
  ~MyLed();

  //ember method
  void turnOn();
  void turnOff();
  void setBlink(bool blink);
  void setInterval(unsigned long int time);

  void loop();
  
};

#endif
